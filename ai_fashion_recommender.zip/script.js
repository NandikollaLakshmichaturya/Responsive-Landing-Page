document.addEventListener('DOMContentLoaded', () => {
    console.log('FitSense landing page loaded successfully.');
});